import React from 'react';
import Nav from './Nav';
import Home from './Home';  
import About from './About';
import Gallry from './Gallry'
import Contact from './Contact'
import  Login  from './Login';
import Logout from './Logout'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap-grid.min.css';
import Register from './Register'

 const App = () => {
  return (
    <div>
<BrowserRouter>
<Nav />
<Routes>
  <Route path='/'element={<Home />}/>
  <Route path='/about' element={<About />}/>
  <Route path='/Gallry' element={<Gallry />}/>
  <Route path='/Contact' element={<Contact />}/>
  <Route path='/Logout' element={<Logout />}/>  
  <Route path='/Login' element={<Login />}/>   
  <Route path='/Register' element={<Register />}/> 
   
</Routes>
</BrowserRouter>

    </div>
  )
}
export default App;