import React from "react";
import Footer from "./Footer";
const contact = () => {
  return (
    <>
      <div className="header">
        <h1
          style={{
            textAlign: "center",
            textShadow: "-1px 1px 10px red",
            color: "white",
            fontSize: "50px",
          }}
        >
          {/* Welcome My Laptop Shop */}
        </h1>
        <div>
          <form action="" className="f1">
            <h1
              style={{
                color: "red",
                textAlign: "center",
                textShadow: "3px 2px 2px white",
              }}
            >
              CONTACT FORM
            </h1>
            <br />
            
            <lable>Full Name &nbsp;:</lable>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="text" name="name" placeholder="Enter full name" />
            <br />
            <br />
            <label>Mobile no &nbsp;:</label>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="text" name="number" placeholder="Enter phone no" />
            <br />
            <br />
            <label>Subject &nbsp;&nbsp;:</label>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <textarea class="text"></textarea>
            <br />
            <br />
            <input type="submit" name="submit" class="btn" value="submit" />
          </form>
          <br />
          <br />
          <br />
          <hr />
          <Footer />
        </div>
      </div>
    </>
  );
};
export default contact;
