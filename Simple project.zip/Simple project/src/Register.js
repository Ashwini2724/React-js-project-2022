import React from 'react'
import Footer from './Footer';
 const Register = () => {
  return (
    <>
      <div className="header">
        <h1
          style={{
            textAlign: "center",
            textShadow: "-1px 1px 10px red",
            color: "white",
            fontSize: "50px",
          }}
        >
          {/* Welcome My Laptop Shop */}
        </h1>
        <div>
          <form action="" className="f2">
            <h1
              style={{
                color: "white",
                textAlign: "center",
                textShadow: "3px 2px 2px blue",
                fontSize: "40px",
              }}
            >
              Register Form
            </h1>
            <br />
            <lable>Full name &nbsp;:</lable>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="text" name="name" placeholder="Enter full name" />
            <br />
            <br />
            <lable>DOB &nbsp;:</lable>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="date" name="date"  />
            <br />
            <br />
           
            <lable>Email &nbsp;:</lable>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="Email" name="email" placeholder="Enter Email" />
            <br />
            <br />
            <label>Password &nbsp;:</label>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input
              type="password"
              name="password"
              placeholder="Enter password"
            />
            <br />
            <br />
            <input type="submit" name="submit" class="btn2" value="Register" />
           
            <br />
            <button ><a href="Login">Already have an account?Login here</a></button>
          </form>
          <br />
          <br />
          <br />
          <hr />
          <Footer />
        </div>
      </div>
    </>
  )
}
export default Register;