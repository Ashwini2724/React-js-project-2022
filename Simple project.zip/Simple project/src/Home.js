import React from "react";
import Footer from "./Footer";

const Home = () => {
  return (
    <>
      <div className="header">
        <h1
          style={{
            textAlign: "center",
            textShadow: "-1px 1px 10px red",
            color: "white",
            fontSize: "50px",
          }}
        >
          Welcome My Laptop Shop
        </h1>
        <div>
          <center>
            <img
              src="https://essenceofemail.com/wp-content/uploads/2019/09/36-1200x640.png"
              width="1200px"
              height="300px"
              alt=""
          
            />
          </center>
          <div>
            <p className="para">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              A laptop, laptop computer, or notebook computer is a small,
              portable personal computer (PC) with a screen and alphanumeric
              keyboard. Laptops typically have a clam shell form factor with the
              screen mounted on the inside of the upper lid and the keyboard on
              the inside of the lower lid, although 2-in-1 PCs with a detachable
              keyboard are often marketed as laptops or as having a laptop mode.
              Laptops are folded shut for transportation, and thus are suitable
              for mobile use. Its name comes from lap, as it was deemed
              practical to be placed on a person's lap when being used. Today,
              laptops are used in a variety of settings, such as at work, in
              education, for playing games, web browsing, for personal
              multimedia, and for general home computer use. As of 2021, in
              American English, the terms laptop computer and notebook computer
              are used interchangeably; in other dialects of English, one or the
              other may be preferred. Although the terms notebook computers or
              notebooks originally referred to a specific size of laptop . the
              terms have come to mean the same thing and notebook no longer
              refers to any specific size.
            </p>
         
          </div>
          <hr />
          <Footer />
        </div>
      </div>
    </>
  );
};
export default Home;
