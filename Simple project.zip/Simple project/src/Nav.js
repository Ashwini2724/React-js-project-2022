import React from 'react'
import { Link } from 'react-router-dom';
import './index.css';

 const Nav = () => {
  return (
    <div className='nav'>
        <ul>
            <li>
                          
                <Link to='/'>Home</Link>
                <Link to='/about'>About</Link>
                <Link to='./Gallry'>Gallry</Link>
                <Link to='/contact'>Contact</Link>
                <Link to='/Register'>Register</Link>
                <Link to='/Login' style={{padding:'0',margin: '5px'}}></Link>
                <Link to='/Login'>Logout</Link>
            </li>
        </ul>
    </div>
  )
}
export default Nav;