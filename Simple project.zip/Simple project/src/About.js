import React from "react";
import Footer from "./Footer";

const About = () => {
  return (
    <>
      <div className="header">
        <h1
          style={{
            textAlign: "center",
            textShadow: "-1px 1px 10px red",
            color: "white",
            fontSize: "50px",
          }}
        >
          Welcome My Laptop Shop
        </h1>
        <div>
          <img
            src="https://media.istockphoto.com/photos/businessman-in-office-talking-on-phone-picture-id1158791616?k=20&m=1158791616&s=612x612&w=0&h=GGo_DTDkZVZMgF9Ithta_nHlF8mtsBF_geP8-S0xVP8="
            height="300px"
            width="400px"
            title="beautiful image"
            align="left"
          />
          <p className="para1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            Laptops combine all the input/output components and capabilities of
            a desktop computer, including the display screen, small speakers, a
            keyboard, data storage device, sometimes an optical disc drive,
            pointing devices (such as a touch pad or pointing stick), with an
            operating system, a processor and memory into a single unit. Most
            modern laptops feature integrated webcams and built-in microphones,
            while many also have touchscreens. Laptops can be powered either
            from an internal battery or by an external power supply from an AC
            adapter. Hardware specifications, such as the processor speed and
            memory capacity, significantly vary between different types, models
            and price points.
          </p>
          <p className="para1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            Design elements, form factor and construction can also vary
            significantly between models depending on the intended use. Examples
            of specialized models of laptops include rugged notebooks for use in
            construction or military applications, as well as low production
            cost laptops such as those from the One Laptop per Child (OLPC)
            organization, which incorporate features like solar charging and
            semi-flexible components not found on most laptop computers.
            Portable computers, which later developed into modern laptops, were
            originally considered to be a small niche market, mostly for
            specialized field applications, such as in the military, for
            accountants, or traveling sales representatives. As portable
            computers evolved into modern laptops, they became widely used for a
            variety of purposes.
          </p>

         
          
         
          <hr />
          <Footer />
        </div>
      </div>
    </>
  );
};
export default About;
